-- SCDA Online Editor -- 

T - Toggle Editor
W - Move Forward
S - Move Backward
E - Move Up
Q - Move Down
A - Move Left
D - Move Right
. - Increase Movement Speed
, - Decrease Movement Speed
+ = Increase Selection Radius
- = Decrease Selection Radius
F - Select Range
M - Move Selection
N - Select Next Modified Object
P - Select Previous Modified Object
R = Reset Selected Modified Object
Y = Apply Selection


EditMap ..\Packages\_Common\MapsPC\SLHE1_VS.sds
EditMap ..\Packages\_Common\MapsPC\REDE2_VS.sds
EditMap ..\Packages\_Common\MapsPC\BLE_VS.sds
EditMap ..\Packages\_Common\MapsPC\USSE4_VS.sds
EditMap ..\Packages\_Common\MapsPC\MOTE5_VS.sds
EditMap ..\Packages\_Common\MapsPC\TERE6_VS.sds
EditMap ..\Packages\_Common\MapsPC\BOSE7_VS.sds
EditMap ..\Packages\_Common\MapsPC\WAVE8_VS.sds

SaveMap SLHE1_VS.sds
SaveMap REDE2_VS.sds
SaveMap BLE_VS.sds
SaveMap REDE2_VS.sds
SaveMap USSE4_VS.sds
SaveMap MOTE5_VS.sds
SaveMap TERE6_VS.sds
SaveMap BOSE7_VS.sds
SaveMap WAVE8_VS.sds