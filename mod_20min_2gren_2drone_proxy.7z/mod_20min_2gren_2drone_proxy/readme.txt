







20 minutes
2 drones
2 grenades
audio proxy sensor only
3 jammers, 90 seconds each



